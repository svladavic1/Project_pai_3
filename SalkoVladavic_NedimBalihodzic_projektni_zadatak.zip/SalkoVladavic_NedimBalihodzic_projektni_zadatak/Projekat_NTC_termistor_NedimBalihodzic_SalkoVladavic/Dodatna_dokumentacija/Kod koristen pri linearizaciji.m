R1 = [5.6 5.5 5.2 5.1 5.0 4.9 4.8 4.6 4.4 4.3 4.2 4.1 4.0 3.8 3.7 3.6 3.5 3.4 3.3 3.2 3.1 3.0 3.0 2.9 2.8 ];
    
R2= [2.4 2.2 2.3 2.1 2.1 2.0 2 1.9 1.8 1.8];
R3 = [1.7 1.7 1.7 1.7 1.7 1.7 1.7 1.7 1.7 1.6 1.6 1.6 1.6 1.6 1.5 1.5 1.5 1.5 1.4 1.4 1.4 1.3 1.3 1.3 1.2 1.2 1.2 1.2 1.2 1.1 1.1 1 1.1 1.1 1 1 1 1 0.9 0.9 .9 .9 .9 .9 .9 .9 .9 .8 .8 .8 .8 .8 .8 .8 .8 .7  .7 .7 .7 .7 ];

R = [R1,R2,R3];
T1 = 26:1:50;
T2 = 51:1:60;
T3 = 61:1:120;
T = [T1, T2, T3];
T5 = 26 :1: 60
 T1_K = 26+273:1:50+273;
 T2_K = 51+273:1:60+273;
 T3_K = 61+273:1:120+273;
 T_K = [T1_K, T2_K, T3_K];
figure(1)
title('Stati�ka karakteristike dobivena na osnovu mjerenja');
plot(T,R,'m*');
xlabel('T [\circC]');
ylabel('R [\Omega]');
hold on;
grid on;

figure(2)
R5 = -0.01959 * T3 +  2.953; 
title('Aproksimacija stati�ke karakteristike koriste�i dvije prave');
plot(T3,R5,'r');
xlabel('T [\circC]');
ylabel('R [\Omega]');
hold on;
R6 = -0.1134* T5 + 8.352
plot(T5,R6,'b');
plot(T, R, 'c');
grid on;
legend('Prva prava', 'Druga prava' , 'Laboratorijska mjerenja' )
figure(3)
title('Aproksimacija stati�ke karakteristike koriste�i tri prave');
R1 =  -0.1171 * T1 + 8.489
R2 =  -0.06424 * T2 + 5.625
R3 =  -0.01959 * T3 + 2.953 
xlabel('T [\circC]');
ylabel('R [\Omega]');
hold on;
plot(T1,R1,'r');
plot(T2,R2,'b');
plot(T3,R3,'k');
plot(T, R, 'c')
grid on;
R8 = 0.0004077.*exp(2849*(1./T_K));
legend('Prva prava', 'Druga prava' , 'Tre�a prava', 'Laboratorijska mjerenja')
%Ovdje su navedeni vrijednosti ovih plot za Kelvine
% Y1_K = -0.1171 * T1 + 40.45;
% Y2_K = -0.06424 * T2 + 23.16;
% Y3_K =  -0.01959 * T3 + 8.301;
% Y1 = -0.1171 * T1 + 8.489
% Y2 = -0.06424 * T2 + 5.625
% Y3 =  -0.01959 * T3 + 2.953
% plot(T1,Y1,'k');
% plot(T2,Y2,'k');
% plot(T3,Y3,'k')
Rs = 56;
U = 0.5;
Uv = (U.*R)./(R+Rs);
Uv1 = (U.*R1)./(R1+Rs);
Uv2 = (U.*R2)./(R2+Rs);
Uv3 = (U.*R3)./(R3+Rs);
figure(4)
title('Aproksimacija radne karakteristike koriste�i tri prave')
grid on;
hold on;
R8 = 0.0004077.*exp(2849*(1./T_K));
Uv8 = (U.*R8)./(R8+Rs);
plot(T1,Uv1,'r');
plot(T2,Uv2,'b');
plot(T3,Uv3,'k');
plot(T,Uv,'c');
plot(T,Uv8,'m');
xlabel('Temperatura \circC')
ylabel('Napon (V)')
legend( 'Prvi linearizirani dio','Drugi linearizirani dio', 'Treci linearizirani dio','Ta�ke dobivene mjerenjem','Aproksimacija nelinearnom karakteristikom');
figure(5)
R7 = -0.04432 * T +  5.261; 
title('Aproksimacija stati�ke karakteristike koriste�i jednu pravu');
plot(T,R7,'r');
xlabel('T [\circC]');
ylabel('R [\Omega]');
hold on;
plot(T, R, 'c');
grid on;
legend('Linearna aproksimacija','Laboratorijska mjerenja' );
figure(6)
title('Aproksimacija stati�ke karakteristike');
plot(T_K,R8,'r');
xlabel('T [K]');
ylabel('R [\Omega]');
hold on;
plot(T_K, R, 'c');
grid on;
legend('Aproksimacija','Laboratorijska mjerenja' );

